export const theme = {
    bg: opacity => `rgba(249, 115, 22, ${opacity})`,
    text: '#f97316'
}